package com.dsw.business.models.models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.dsw.conection.Conexion;
import com.dsw.data.userEntity;

public class userModel {
	public userEntity iniciarSesion(String user, String password) {
		userEntity usuario = null;
		Connection cn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		
		try {
			cn = Conexion.getConexion();
			String sql = "SELECT U.customerid, U.username, U.name, U.firstlastname,"
					+ "U.secondlastname, U.birthdaydate, U.streetdirection,"
					+ "U.streetnumber, U.telephone1, U.telephone2,"
					+ "U.password, U.email FROM customer U WHERE U.username = ? AND U.password = ?";
			pstm = cn.prepareStatement(sql);
			pstm.setString(1, user);
			pstm.setString(2, password);
			rs = pstm.executeQuery();
			
			while (rs.next()) {
				usuario = new userEntity();
				usuario.setCustomerid(rs.getInt("customerid"));
				usuario.setUsername(rs.getString("username"));
				usuario.setName(rs.getString("name"));
				usuario.setFirstlastname(rs.getString("firstlastname"));
				usuario.setSecondlastname(rs.getString("secondlastname"));
				usuario.setBirthdaydate(rs.getString("birthdaydate"));
				usuario.setStreetdirection(rs.getString("streetdirection"));
				usuario.setStreetnumber(rs.getInt("streetnumber"));
				usuario.setTelephone1(rs.getInt("telephone1"));
				usuario.setTelephone2(rs.getInt("telephone2"));
				usuario.setPassword(rs.getString("password"));
				usuario.setEmail(rs.getString("email"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				
				if (pstm != null) {
					pstm.close();
				}
				
				if (cn != null) {
					cn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		return usuario;
	}
}
