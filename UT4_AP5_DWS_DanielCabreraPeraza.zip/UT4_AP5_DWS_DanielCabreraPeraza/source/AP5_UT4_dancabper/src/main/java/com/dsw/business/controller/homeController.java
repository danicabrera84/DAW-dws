package com.dsw.business.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dsw.data.userEntity;
import com.dsw.business.models.models.userModel;


@WebServlet("/homeController")
public class homeController extends HttpServlet {
	private static final long serialVersionUID = 2L;
	
	
	
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String tipo = request.getParameter("tipo");
		
		
			if ("iniciarSesion".equals(tipo)) {
				this.iniciarSesion(request, response);
			} else if ("cerrarSesion".equals(tipo)) {
				this.cerrarSesion(request, response);
			}else {
				String user = (String)request.getAttribute("loginok");
				String password = (String)request.getAttribute("passok");
				
				userModel modelo = new userModel();
				userEntity usuario = modelo.iniciarSesion(user, password);
				
				if (usuario != null) {
				HttpSession sesion = request.getSession();
				sesion.setAttribute("user", usuario);
				response.sendRedirect("Views/home.jsp");
				sesion.setAttribute("nombre", usuario.getName()); sesion.setAttribute("apellido1", usuario.getFirstlastname());
				sesion.setAttribute("apellido2", usuario.getSecondlastname()); sesion.setAttribute("fecnac", usuario.getBirthdaydate());
				sesion.setAttribute("calle", usuario.getStreetdirection()); sesion.setAttribute("numcalle", usuario.getStreetnumber());
				sesion.setAttribute("telefono1", usuario.getTelephone1()); sesion.setAttribute("telefono2", usuario.getTelephone2());
				sesion.setAttribute("email", usuario.getEmail()); sesion.setAttribute("nusuario", usuario.getUsername());
					}
				}
	
	}
	
	private void iniciarSesion(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String user = request.getParameter("user");
		String password = request.getParameter("password");
		
		userModel modelo = new userModel();
		userEntity usuario = modelo.iniciarSesion(user, password);

		if (usuario == null) {
			request.setAttribute("mensaje","Usuario o contrasena incorrecto");
			request.getRequestDispatcher("errorController").forward(request, response);
		} else {
			Cookie userlog = new Cookie("userlogueado", user);
			Cookie passlog = new Cookie("passlogueado", password);
			userlog.setMaxAge(60);
			passlog.setMaxAge(60);
			response.addCookie(userlog);
			response.addCookie(passlog);
			
			HttpSession sesion = request.getSession();
			sesion.setAttribute("user", usuario);
			response.sendRedirect("Views/home.jsp");
			sesion.setAttribute("nombre", usuario.getName()); sesion.setAttribute("apellido1", usuario.getFirstlastname());
			sesion.setAttribute("apellido2", usuario.getSecondlastname()); sesion.setAttribute("fecnac", usuario.getBirthdaydate());
			sesion.setAttribute("calle", usuario.getStreetdirection()); sesion.setAttribute("numcalle", usuario.getStreetnumber());
			sesion.setAttribute("telefono1", usuario.getTelephone1()); sesion.setAttribute("telefono2", usuario.getTelephone2());
			sesion.setAttribute("email", usuario.getEmail()); sesion.setAttribute("nusuario", usuario.getUsername());
		}
	}
	
	private void cerrarSesion(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cookieUsuario = "";
		String cookiePassword = "";
		Cookie[] cookies = request.getCookies();
		if(cookies != null) {
			for(Cookie cookie_temporal: cookies) {
				if("userlogueado".equals(cookie_temporal.getName())) {
					cookieUsuario = cookie_temporal.getValue();
					
				}
				
				if("passlogueado".equals(cookie_temporal.getName())) {
					cookiePassword = cookie_temporal.getValue();
				}
			}
		}
		Cookie userlog = new Cookie("userlogueado", cookieUsuario);
		Cookie passlog = new Cookie("passlogueado", cookiePassword);
		
		userlog.setMaxAge(0);
		passlog.setMaxAge(0);
		response.addCookie(userlog);
		response.addCookie(passlog);
		
		HttpSession sesion = request.getSession();
		sesion.invalidate();
		
		
		request.setAttribute("mensaje","Sesion cerrada correctamente");
		request.getRequestDispatcher("errorController").forward(request, response);
	}
	

	

}
