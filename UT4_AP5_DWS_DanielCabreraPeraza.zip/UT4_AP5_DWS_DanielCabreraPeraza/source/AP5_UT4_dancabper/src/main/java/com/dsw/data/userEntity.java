package com.dsw.data;

public class userEntity {
	
	private int customerid;
	private String username;
	private String name;
	private String firstlastname;
	private String secondlastname;
	private String birthdaydate;
	private String streetdirection;
	private int streetnumber;
	private int telephone1;
	private int telephone2;
	private String password;
	private String email;
	public int getCustomerid() {
		return customerid;
	}
	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFirstlastname() {
		return firstlastname;
	}
	public void setFirstlastname(String firstlastname) {
		this.firstlastname = firstlastname;
	}
	public String getSecondlastname() {
		return secondlastname;
	}
	public void setSecondlastname(String secondlastname) {
		this.secondlastname = secondlastname;
	}
	public String getBirthdaydate() {
		return birthdaydate;
	}
	public void setBirthdaydate(String birthdaydate) {
		this.birthdaydate = birthdaydate;
	}
	public String getStreetdirection() {
		return streetdirection;
	}
	public void setStreetdirection(String streetdirection) {
		this.streetdirection = streetdirection;
	}
	public int getStreetnumber() {
		return streetnumber;
	}
	public void setStreetnumber(int streetnumber) {
		this.streetnumber = streetnumber;
	}
	public int getTelephone1() {
		return telephone1;
	}
	public void setTelephone1(int telephone1) {
		this.telephone1 = telephone1;
	}
	public int getTelephone2() {
		return telephone2;
	}
	public void setTelephone2(int telephone2) {
		this.telephone2 = telephone2;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
