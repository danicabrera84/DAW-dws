package com.dsw.conection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexion {
	
	private static final String Driver = "com.mysql.cj.jdbc.Driver";
    private static final String Url = "jdbc:mysql://localhost:3306/commercedb";
    private static final String Usuario = "root";
    private static final String Pass = "";
    
    static {
    	try {
            Class.forName(Driver);
        } catch (ClassNotFoundException e) {
            System.out.println("Error al cargar el driver");
            e.printStackTrace();
        }
    }
    
    public static Connection getConexion() {
        Connection conexion = null;
        
        try {
            conexion = DriverManager.getConnection(Url, Usuario, Pass);
            System.out.println("Conexi�n Establecida");

        } catch (SQLException e) {
            System.out.println("Error en la Conexion");
            e.printStackTrace();
        }
        
        return conexion;
    }
}
