<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>Tira los Dados y Gana</title>
</head>
<body>
<div class="contenedor">

    <div class="dados">
        <?php
        $dado1 = rand(1, 6);
        $dado2 = rand(1, 6);
        $dado3 = rand(1, 6);
        $dado4 = rand(1, 6);
        $dado5 = rand(1, 6);
        $dado6 = rand(1, 6);
        $lose = rand(7, 8);
        $sorteo = rand(9, 12);
        $piruleta = rand(13, 15);

        if ($sorteo == 9) {
            $premio = "un peluche";
        }elseif ($sorteo == 10) {
            $premio = "un balon de futbol";
        }elseif ($sorteo == 11) {
            $premio = "un balon de baloncesto";
        }elseif ($sorteo == 12) {
            $premio = "2 entradas para el cine";
        }
        print "  <p>\n";
        print "    <img src=\"img/$dado1.png\" alt=\"$dado1\" width=\"140\" height=\"140\">\n";
        print "    <img src=\"img/$dado2.png\" alt=\"$dado2\" width=\"140\" height=\"140\">\n";
        print "    <img src=\"img/$dado3.png\" alt=\"$dado3\" width=\"140\" height=\"140\">\n";
        print "    <img src=\"img/$dado4.png\" alt=\"$dado4\" width=\"140\" height=\"140\">\n";
        print "    <img src=\"img/$dado5.png\" alt=\"$dado5\" width=\"140\" height=\"140\">\n";
        print "    <img src=\"img/$dado6.png\" alt=\"$dado6\" width=\"140\" height=\"140\">\n";
        print "  </p>\n";
        print "\n";
        ?>
    </div>

    <button class="boton" onclick="setTimeout(function(){location.reload();});">Tirar dados</button>

    <div class="cabecera">
        <h3>¿ Ganarás el Premio Extraordinario ?</h3>
    </div>   
    

    <div class="billetes">
        <?php
            $hoy = getdate();
            $hora = $hoy["hours"];
            if ($dado1 == 6 and $dado2 == 6 and $dado3 == 6 and $dado4 == 6 and $dado5 == 6 and $dado6 == 6) {
                $resta = 24 - $hora;
                $operacion = $resta * 100;
                for ($i=1; $i <=$resta ; $i++) { 
                    print "  <p>\n";
                    print "    <img src=\"img/billete100e.png\" alt=\"billete100e\" width=\"140\" height=\"80\">\n";
                    print "  </p>&nbsp;\n";
                    print "\n";
                }
                print "  <p>¡¡Felicidades, has ganado el premio extraordinario!!</p>\n";
            }else{
                print "  <p>\n";
                print "    <img src=\"img/$lose.png\" alt=\"$lose\" width=\"300\" height=\"120\">\n";
                print "  </p>\n";
                print "\n";
            }
        ?>
    </div>

    <div class="cabecera">
        <h3>¿ Participarás en el Sorteo ?</h3>
    </div> 

    <div class="sorteo">
        <?php
            $hoy = getdate();
            $dia = $hoy["mday"];
            $sumatoria = $dado1 + $dado2 + $dado3 + $dado4 + $dado5 + $dado6;
             if ($sumatoria == $dia) {
                print "  <p>\n";
                print "    <img src=\"img/$sorteo.png\" alt=\"$sorteo\" width=\"300\" height=\"240\">\n";
                print "  </p>&nbsp;&nbsp;\n";
                print "\n";
                print "  <p>¡¡Felicidades, has ganado $premio en el sorteo aleatorio!!</p>\n"; 
             }else{
                print "  <p>\n";
                print "    <img src=\"img/$lose.png\" alt=\"$lose\" width=\"300\" height=\"120\">\n";
                print "  </p>\n";
                print "\n";
            }  
        ?>
    </div>

    <div class="cabecera">
        <h3> Piruletas ganadas en la tirada </h3>
    </div>
    
    <div class="piruletas">
        <?php
        
        $Dadosresult = array($dado1, $dado2, $dado3, $dado4, $dado5, $dado6);
        $VFrecuencia = array_count_values($Dadosresult);
        $Faux_actual = 0;
        $Key_actual = 0;
        $Key_seleccionado = 0;

        for ($i = 0; $i < 6; $i++){
            $Faux_actual = $VFrecuencia[$Dadosresult[$i]];
            $Key_actual = $Dadosresult[$i];
            if ($Faux_actual >= 2){
                   
             if ($Key_actual > $Key_seleccionado)
                {
                    $Key_seleccionado = $Key_actual;
                }
            }
        } 
        
        if ($Key_seleccionado == 0)
        print "No hay pares de dados";
       else
        
        for ($i=1; $i <=$Key_seleccionado ; $i++){
            $piruleta1 = 13; $piruleta2 = 14; $piruleta3 = 15;
            $piruletasall = rand($piruleta1, $piruleta3);
            if (i == 1) {
                print "  <p>\n";
                print "    <img src=\"img/losing.png\" alt=\"losing.png\" width=\"300\" height=\"120\">\n";
                print "  </p>\n";
                print "\n";
            } else {
                print "  <p>\n";
                print "    <img src=\"img/$piruletasall.gif\" alt=\"$piruleta\" width=\"100\" height=\"140\">\n";
                print "  </p>&nbsp;\n";
                print "\n";
            }
        }

        $par = 0;
        if ($dado1%2 == 0) {
            $par++;
        }
        if ($dado2%2 == 0) {
            $par++;
        }
        if ($dado3%2 == 0) {
            $par++;
        }
        if ($dado4%2 == 0) {
            $par++;
        }
        if ($dado5%2 == 0) {
            $par++;
        }
        if ($dado6%2 == 0) {
            $par++;
        }
        if ($par == 6) {
            print "  <p>¡¡Felicidades, puedes volver a tirar los dados!!</p>\n";
        }else {
            print "  <p>¡¡Oh, no ha tenido suerte, para otra vez será!!</p>\n";
        }
        /*$dadosrep = array($dado1, $dado2, $dado3, $dado4, $dado5, $dado6);
        $valores = array_count_values($dadosrep);
        $keys = array_keys($valores,max($valores));
        //print_r($keys);
        //print_r(max($keys));
        for ($i=1; $i <=max($keys) ; $i++) {
            if (i == 1) {
                print "  <p>\n";
                print "    <img src=\"img/$lose.png\" alt=\"$lose\" width=\"300\" height=\"120\">\n";
                print "  </p>\n";
                print "\n";
            } else {
                print "  <p>\n";
                print "    <img src=\"img/$piruleta.gif\" alt=\"$piruleta\" width=\"100\" height=\"140\">\n";
                print "  </p>&nbsp;\n";
                print "\n";
            }  
        }
        $par = 0;
        if ($dado1%2 == 0) {
            $par++;
        }
        if ($dado2%2 == 0) {
            $par++;
        }
        if ($dado3%2 == 0) {
            $par++;
        }
        if ($dado4%2 == 0) {
            $par++;
        }
        if ($dado5%2 == 0) {
            $par++;
        }
        if ($dado6%2 == 0) {
            $par++;
        }
        if ($par == 6) {
            print "  <p>¡¡Felicidades, puedes volver a tirar los dados!!</p>\n";
        }else {
            print "  <p>¡¡Oh, no ha tenido suerte, para otra vez será!!</p>\n";
        }*/
        ?>
    </div>
</div>
</body>
</html>