<?php
require 'view/contenido.view.php';
?>