<?php
session_start();

include '../Connect4/functionsclass/functions.php';
include '../Connect4/functionsclass/class.php';

$_SESSION["partidaNueva"] = true;
$_SESSION["datosCorrectos"] = false;
$_SESSION["tablero"] = array();
      
Errores();
$jugador1 = new Jugador;
$jugador2 = new Jugador;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conecta 4</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

<div class="cabecera">
    <h1>Formulario de Inscripción</h1>
</div>

<div class="contenedor">

    <form action="view/partida.php" method="post">

        <?php
            $jugador1->nombre = "nombre1";
            $jugador1->apellidos = "apellidos1";
            $jugador1->direccion = "direccion1";
            $jugador1->provincia = "provincia1";
            $jugador1->municipio = "municipio1";
            $jugador1->edad = "edad1";
            $jugador1->color = "color1";
        ?>

        <div class="jugador1">
            <input type="text" placeholder="Nombre: " name="<?php echo $jugador1->nombre;?>" id="nombre">
                &nbsp;
            <input type="text" placeholder="Apellidos: " name="<?php echo $jugador1->apellidos;?>" id="apellidos">
                &nbsp;
            <input type="text" placeholder="Dirección: " name="<?php echo $jugador1->direccion;?>" id="direccion">
                &nbsp;
            <label for="provincia">Provincia:&nbsp;</label>
            <select id="provincia1" name="<?php echo $jugador1->provincia;?>">
                <option value="Las Palmas" selected>Las Palmas</option>
                <option value="Santa Cruz">Santa Cruz</option>
            </select>
                &nbsp;
            <label for="municipio">Municipio:</label>
            <select id="municipio1" name="<?php echo $jugador1->municipio;?>">'
                <option value="Las Palmas" selected>Las Palmas</option>
                <option value="Telde">Telde</option>
                <option value="Santa Cruz">Santa Cruz</option>
                <option value="La Laguna">La Laguna</option>
            </select>
                &nbsp;
            <label for="edad">Edad:</label>
            <select id="edad1" name="<?php echo $jugador1->edad;?>">'
                <option value="18 a 25" selected>18 a 25</option>
                <option value="26 a 40">26 a 40</option>
                <option value="41 a 60">41 a 60</option>
                <option value="Mayor 60">Mayor 60</option>
            </select>
                &nbsp;
            <label for="color">Color:</label>
            <select id="color1" name="<?php echo $jugador1->color;?>">'
                <option value="Rojo" style="background: red;"  selected>Rojo</option>
                <option value="Amarillo" style="background: yellow;">Amarillo</option> 
            </select>  
        </div>

            <br>
            <br>

        <?php
            $jugador2->nombre = "nombre2";
            $jugador2->apellidos = "apellidos2";
            $jugador2->direccion = "direccion2";
            $jugador2->provincia = "provincia2";
            $jugador2->municipio = "municipio2";
            $jugador2->edad = "edad2";
            $jugador2->color = "color2";
        ?>

        <div class="jugador2">
            <input type="text" placeholder="Nombre: " name="<?php echo $jugador2->nombre; ?>" id="nombre2">
                &nbsp;
            <input type="text" placeholder="Apellidos: " name="<?php echo $jugador2->apellidos; ?>" id="apellidos2">
                &nbsp;
            <input type="text" placeholder="Dirección: " name="<?php echo $jugador2->direccion; ?>" id="direccion2">
                &nbsp;
            <label for="provincia">Provincia:&nbsp;</label>
            <select name="<?php echo $jugador2->provincia; ?>">
                <option value="Las Palmas" selected>Las Palmas</option>
                <option value="Santa Cruz">Santa Cruz</option>
            </select>
                &nbsp;
            <label for="municipio">Municipio:</label>
            <select id="municipio2" name="<?php echo $jugador2->municipio; ?>">'
                <option value="Las Palmas" selected>Las Palmas</option>
                <option value="Telde" >Telde</option>
                <option value="Santa Cruz">Santa Cruz</option>
                <option value="La Laguna">La Laguna</option>
            </select>
                &nbsp;
            <label for="edad">Edad:</label>
            <select id="edad2" name="<?php echo $jugador2->edad; ?>">'
                <option value="18 a 25" selected>18 a 25</option>
                <option value="26 a 40">26 a 40</option>
                <option value="41 a 60">41 a 60</option>
                <option value="Mayor 60">Mayor 60</option>>
            </select>
                &nbsp;
            <label for="color">Color:</label>
            <select id="color2" name="<?php echo $jugador2->color; ?>">'
                <option value="Rojo" style="background: red;">Rojo</option>
                <option value="Amarillo" style="background: yellow;" selected>Amarillo</option>
            </select>
        </div>

        <div class="footer">
            <input style="width: 40%" type="submit" value="Enviar"> 
        </div>
    </form>

</div>


</body>
</html>