<?php

class Jugador{
    public $nombre;
    public $apellidos;
    public $direccion;
    public $provincia;
    public $municipio;
    public $edad;
    public $color;

    
}
?>