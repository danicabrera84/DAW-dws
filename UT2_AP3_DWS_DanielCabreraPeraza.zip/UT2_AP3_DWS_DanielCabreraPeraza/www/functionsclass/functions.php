<?php

function Errores(){
    if (isset($_GET['errorCode1'])) {
        $msg = "No ha introducido el nombre del jugador";
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }
    if (isset($_GET['errorCode2'])) {
        $msg = "No ha introducido el apellido del jugador";
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }
    if (isset($_GET['errorCode3'])) {
        $msg = "No ha introducido la dirección del jugador";
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }
    if (isset($_GET['errorCode4'])) {
        $msg = "Los jugadores no pueden tener el mismo color de ficha";
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }
}

function Redturn(){
    $msjRojo = "Turno del Jugador1";
    if (!$_SESSION["TurnoAmarillos"]){
        echo "<label for=\"msj\" style=\"color: blue;\">$msjRojo</label>";
    } 
        
}

function Yellowturn(){
    $msjAmar = "Turno del Jugador2";
    if ($_SESSION["TurnoAmarillos"]){
        echo "<label for=\"msj\" style=\"color: blue;\">$msjAmar</label>";
    }
}

?>
