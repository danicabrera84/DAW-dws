<?php

include '../functionsclass/functions.php';
session_start();

if (!$_SESSION["datosCorrectos"]){
if (empty($_POST['nombre1'])) {
    $errorCode1 = "errorCode1";
    header("Location: ../index.php?".$errorCode1);
} else {
    $_SESSION["nombre1"] = $_POST['nombre1'];
}

if (empty($_POST['nombre2'])) {
    $errorCode1 = "errorCode1";
    header("Location: ../index.php?".$errorCode1);
} else {
    $_SESSION["nombre2"] = $_POST['nombre2'];
}

if (empty($_POST['apellidos1']) or empty($_POST['apellidos2'])) {
    $errorCode2 = "errorCode2";
    header("Location: ../index.php?".$errorCode2);
}
if (empty($_POST['direccion1']) or empty($_POST['direccion2'])) {
    $errorCode3 = "errorCode3";
    header("Location: ../index.php?".$errorCode3);
}
if ($_POST['color1'] == $_POST['color2']) {
    $errorCode4 = "errorCode4";
    header("Location: ../index.php?".$errorCode4);
}

if ($_POST['color1'] == "Amarillo") {
    $_SESSION['colorJugador1'] = "yellow";
    $_SESSION['colorJugador2'] = "red";
}else {
    $_SESSION['colorJugador1'] = "red";
    $_SESSION['colorJugador2'] = "yellow";
}



$_SESSION["datosCorrectos"] = true;

$_SESSION["nombre1"] = $_POST['nombre1'];
$_SESSION["nombre2"] = $_POST['nombre2'];
$_SESSION["apellidos1"] = $_POST['apellidos1'];
$_SESSION["apellidos2"] = $_POST['apellidos2'];
$_SESSION["direccion1"] = $_POST['direccion1'];
$_SESSION["direccion2"] = $_POST['direccion2'];
$_SESSION["provincia1"] = $_POST['provincia1'];
$_SESSION["provincia2"] = $_POST['provincia2'];
$_SESSION["municipio1"] = $_POST['municipio1'];
$_SESSION["municipio2"] = $_POST['municipio2'];
$_SESSION["edad1"] = $_POST['edad1'];
$_SESSION["edad2"] = $_POST['edad2'];
$_SESSION["color1"] = $_POST['color1'];
$_SESSION["color2"] = $_POST['color2'];
$_SESSION["fichasJugador1"] = 32;
$_SESSION["fichasJugador2"] = 32;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/view.css">
    <title>Conecta 4</title>
</head>
<body>

    <div class="cabecera">
        <h1>Bienvenidos al Conecta 4</h1>
    </div>

    <div class="contenedor">
        <div class="grid">
        <?php

        if (isset($_GET["posicion"])) {
            
            if ($_SESSION["tablero"][$_GET["posicion"]] == 0)
            {
                if ($_SESSION["TurnoAmarillos"]) {
                    $_SESSION["tablero"][$_GET["posicion"]]=1;

                    if ($_SESSION["colorJugador1"]=="yellow"){
                        $_SESSION["fichasJugador1"]--;
                    } else {
                        $_SESSION["fichasJugador2"]--;
                    }

                } else {
                    $_SESSION["tablero"][$_GET["posicion"]]=2;

                    if ($_SESSION["colorJugador1"]=="red"){
                        $_SESSION["fichasJugador1"]--;
                    } else {
                        $_SESSION["fichasJugador2"]--;
                    }
                }
                $_SESSION["TurnoAmarillos"]=!$_SESSION["TurnoAmarillos"];
            }
        } else
        {
            if ($_SESSION["partidaNueva"])
            {
                $_SESSION["tablero"] = array();

                //Se inicializa el tablero
                for ($i = 0; $i < 64; $i++) {
                    $_SESSION["tablero"][$i] = 0;
                }

                $_SESSION["TurnoAmarillos"]=true;
                $_SESSION["partidaNueva"] = false;
            }
        }
        ?>
        
        <table border="2px">
        <?php
         $Columnas = 0;
         
         for ($i = 0; $i< 8; $i++){
             echo "<tr>";
             for ($j = 0; $j < 8; $j++)
             {
               echo "<td>";
               if ($_SESSION["tablero"][$Columnas] == 0) {
                   ?>
                   &nbsp;<a href="partida.php?posicion=<?php echo $Columnas ?>">Poner ficha</a>
                   <?php
               }
               else
               {
                    if ($_SESSION["tablero"][$Columnas] == 1){

                        echo '<img src="../img/amarillo.GIF">';
                        
                    } else {

                        echo '<img src="../img/rojo.GIF">';
                    }

               }
               echo "</td>";
                 
              $Columnas++;
             }
             echo "</tr>";
         }
            
         
        ?>
        </table>
        </div>

        <div class="jugadores">
            
            <div class="jugador1" style="<?php echo 'background:'.$_SESSION['colorJugador1'].';'?>">
                <p>
                    <h3>Jugador1</h3>
                    <label class="etiquetas" for="nombre1">Nombre: <?php echo $_SESSION["nombre1"];?></label>
               
                    <label class="etiquetas" for="apellidos1">Apellido: <?php echo $_SESSION['apellidos1'];?></label>
                
                    <label class="etiquetas" for="direccion1">Direccion: <?php echo $_SESSION['direccion1'];?></label>  
                
                    <label class="etiquetas" for="provincia1">Provincia: <?php echo $_SESSION['provincia1'];?></label>
                
                    <label class="etiquetas" for="municipio1">Municipio: <?php echo $_SESSION['municipio1'];?></label>
                
                    <label class="etiquetas" for="edad1">Edad: <?php echo $_SESSION['edad1'];?></label>
                
                    <label class="etiquetas" for="fichas1">Fichas restantes: <?php echo $_SESSION["fichasJugador1"];?></label>
                <br>
                <br>
                <caption>
                <?php
                Yellowturn();      
                ?>
            </caption>       
                </p>
                
            </div>

            <div class="jugador2" style="<?php echo "background:".$_SESSION['colorJugador2'].';'?>">
                <p>
                    <h3>Jugador2</h3>
                    <label class="etiquetas" for="nombre2">Nombre: <?php echo $_SESSION["nombre2"];?></label>
                
                    <label class="etiquetas" for="apellidos2">Apellido: <?php echo $_SESSION['apellidos2'];?></label>
                
                    <label class="etiquetas" for="direccion2">Direccion: <?php echo $_SESSION['direccion2'];?></label>  
                
                    <label class="etiquetas" for="provincia2">Provincia: <?php echo $_SESSION['provincia2'];?></label>
                
                    <label class="etiquetas" for="municipio2">Municipio: <?php echo $_SESSION['municipio2'];?></label>
                
                    <label class="etiquetas" for="edad2">Edad: <?php echo $_SESSION['edad2'];?></label>
                
                    <label class="etiquetas" for="fichas2">Fichas restantes: <?php echo $_SESSION["fichasJugador2"];?></label>
                <br>
                <br>
                <?php
                RedTurn();
                ?>
            </caption>
                </p>
            </div>
        

        </div>
    </div>
</body>

</html>