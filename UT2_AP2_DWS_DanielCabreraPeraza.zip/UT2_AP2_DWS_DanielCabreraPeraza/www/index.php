<?php
setcookie("guardado",true, time() + 120);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <title>Juego del Gato y el Ratón</title>
</head>
<body>
    <div class="cabecera">
        <h1>Bienvenidos al Juego del Gato y el Ratón</h1>
    </div>
    
    <div class="contenedor">
        <?php
            if ((isset($_COOKIE["guardado"])) && ($_COOKIE["guardado"]) == true) {
                echo "<input class=\"button\" type=\"button\" onclick=\"location.href='view/reinicia.php';\" value=\"Nuevo Juego\" />";
                echo "<br>";
                echo "<input class=\"button\" type=\"button\" onclick=\"location.href='view/recupera.php';\" value=\"Continuar Juego\" />";
            } 
            else {
                echo "<input class=\"button\" type=\"button\" onclick=\"location.href='view/reinicia.php';\" value=\"Nuevo Juego\" />";
            }
        ?>
    </div>
    <div class="footer">
        <h3>Autor: Daniel Cabrera Peraza</h3>
    </div>
</body>
</html>