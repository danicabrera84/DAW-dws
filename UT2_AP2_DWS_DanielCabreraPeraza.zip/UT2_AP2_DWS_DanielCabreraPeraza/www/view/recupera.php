<?php
session_start();

$_SESSION["puerta"] = $_COOKIE["puerta"];
$_SESSION["raton"] = $_COOKIE["raton"];
$_SESSION["gato"] = $_COOKIE["gato"];
$_SESSION["cargado"] = true;

header("location: accion.php");
