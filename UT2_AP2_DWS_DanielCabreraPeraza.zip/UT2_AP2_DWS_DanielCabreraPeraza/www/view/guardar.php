<?php
session_start();

setcookie("guardado", true);
setcookie("raton",$_SESSION["raton"]);
setcookie("gato",$_SESSION["gato"]);
setcookie("puerta",$_SESSION["puerta"]);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="shortcut icon" href="../img/favicon.ico" type="image/x-icon">
    <title>Partida Guardada</title>
</head>
<body>
    <script language="javascript">
        alert("La animación se ha guardado correctamente");
    </script>;
    <div class="cabecera">
        <h1>Partida Guardada</h1>
    </div>
    <div class="contenedor">
        <img src="../img/save.gif" alt="friends" width="180" height="210">
        <input class="button" type="button" onclick="location.href='../index.php';" value="Volver al Inicio" />   
    </div>
    <div class="footer">
        <h3>Autor: Daniel Cabrera Peraza</h3>
    </div>
</body>
</html>