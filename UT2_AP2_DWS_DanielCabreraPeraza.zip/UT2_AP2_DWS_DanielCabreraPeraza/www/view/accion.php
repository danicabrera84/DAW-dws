<?php
session_start();
if (!$_SESSION["cargado"]) {
    $_SESSION["gato"]=rand(0,24);
    $_SESSION["raton"]=rand(0,24);
}
$_SESSION["cargado"]=false;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="shortcut icon" href="../img/favicon.ico" type="image/x-icon">
    <title>Gato y Raton</title>
</head>
<body>
    <div class="cabecera">
        <h1>Bienvenidos al Juego del Gato y el Ratón</h1>
    </div>
    <div class="contenedor">
        <div class="grid">
        <?php
        
           
            for ($i=0; $i<=24; $i++) { 

                if ($i % 2 == 0) {
                    print '<div class="gridbl">';
                    
                   
                    
                } else {
                    print '<div class="gridgr">';
                    
                    
                }
                if ($i == $_SESSION["puerta"]) {
                    if (ganaRaton() == true) {
                        print "<td><img src=\"../img/ganaraton.gif\" alt=\"3\" width=\"100\" height=\"100\"></td>";
                        echo '<script language="javascript">';
                        echo 'alert("Jerry ha escapado")';
                        echo '</script>';
                    }
                    elseif (gatoPuerta() == true) {
                        print "<td><img src=\"../img/gatopuerta.gif\" alt=\"3\" width=\"100\" height=\"100\"></td>";
                    }
                    else{
                        print "<td><img src=\"../img/puerta.gif\" alt=\"3\" width=\"100\" height=\"100\"></td>";
                    }
                }
                elseif ($i == $_SESSION["raton"]) {
                    
                    if (ganaGato() == true) {
                        print "<td><img src=\"../img/ganagato.gif\" alt=\"3\" width=\"100\" height=\"100\"></td>";
                        echo '<script language="javascript">';
                        echo 'alert("Tom se ha comido a Jerry")';
                        echo '</script>';
                    }
                    else {
                        print "<td><img src=\"../img/raton.gif\" alt=\"3\" width=\"100\" height=\"100\"></td>";
                    }
                }
                elseif ($i == $_SESSION["gato"]) {
                    
                    if (ganaGato() == true) {
                        print "<td><img src=\"../img/ganagato.gif\" alt=\"3\" width=\"100\" height=\"100\"></td>";
                        echo '<script language="javascript">';
                        echo 'alert("Tom se ha comido a Jerry")';
                        echo '</script>';
                    }
                    else {
                        print "<td><img src=\"../img/gato.gif\" alt=\"3\" width=\"100\" height=\"100\"></td>";
                    }
                }
                print "</div>";

                
                

                
            }

            function ganaRaton(){
                return $_SESSION["raton"] == $_SESSION["puerta"];
            }

            function ganaGato(){
                return $_SESSION["gato"] == $_SESSION["raton"];
            }

            function gatoPuerta(){
                return $_SESSION["gato"] == $_SESSION["puerta"];
            }

        ?>
            
        </div>
    </div>
    <div class="footer">
        <?php
            if (ganaRaton() == true) {
                echo "<input class=\"button\" type=\"button\" onclick=\"location.href='guardar.php';\" value=\"Guardar y Salir\" />";
            }
            elseif (ganaGato() == true) {
                echo "<input class=\"button\" type=\"button\" onclick=\"location.href='guardar.php';\" value=\"Guardar y Salir\" />";
            }
            else {
                echo '<input class="button" type="button" onclick="setTimeout(function(){location.reload();});" value="Acción" />';
                echo "<br>";
                echo "<input class=\"button\" type=\"button\" onclick=\"location.href='guardar.php';\" value=\"Guardar y Salir\" />";
            }
                    
        ?>    
    </div>
    
</body>
</html>