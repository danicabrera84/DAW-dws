<?php
setcookie("JuegoGatoRaton",false, time() + 120);
session_start();
$_SESSION["cargado"]=false;
$_SESSION["gato"]=rand(0,24);
$_SESSION["raton"]=rand(0,24);
$_SESSION["puerta"]=rand(0,24);

header("location: accion.php");
?>