<?php
include 'library/functions.php';
include 'class/class.php';
//getErrors(); //Llamada a función que nos devuelve un codigo de error concreto
getSession(); //Llamada a función que nos redirecciona a home.php si esta iniciada la sesión
$usuario = new clsUsuario('', '');
$usuario->IsError();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <link rel="stylesheet" href="css/styles.css">
    <title>Login</title>
</head>
<body>
    <div class="Contenedor">
        <div class="Icon">
            <span class="glyphicon glyphicon-user"></span>
        </div>
        <div class="ContentForm">
            <?php
                if (isset($_COOKIE["ckdatauser"])) {//Si existe la cookie ckdatauser redireccionaremos por método GET  hacia validateuser.php
                    header("Location: view/validateuser.php");
                } 
                else {//Si no existe la cookie mostramos un formulario en el que se solicita usuario y contraseña
                    print "<form action=\"view/validateuser.php\" method=\"post\" name=\"FormEntrar\">";// Enviamos datos por metodo post a validateuser.php
                    print "<div class=\"input-group input-group-lg\">";
                    print "<span class=\"input-group-addon\" id=\"sizing-addon1\"><i class=\"glyphicon glyphicon-user\"></i></span>";
                    print "<input type=\"text\" class=\"form-control\" name=\"usuario\" placeholder=\"Usuario\" id=\"Text\" aria-describedby=\"sizing-addon1\" required>";
                    print "</div>";
                    print "<br>";
                    print "<div class=\"input-group input-group-lg\">";
                    print "<span class=\"input-group-addon\" id=\"sizing-addon1\"><i class=\"glyphicon glyphicon-lock\"></i></span>";
                    print "<input type=\"password\" name=\"contra\" class=\"form-control\" placeholder=\"******\" aria-describedby=\"sizing-addon1\" required>";
                    print "</div>";
                    print "<br>";
                    print "<button class=\"btn btn-lg btn-primary btn-block btn-signin\" id=\"IngresoLog\" type=\"submit\">Entrar</button>";
                    print "<div class=\"opcioncontra\"><a href=\"view/newuser.php\">Nueva Cuenta</a>";// Este enlace nos redirecciona a newuser.php
                    print "</div>";
                    print "</form>";
                }
            ?>
        </div>   
    </div>   
</body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</html>

