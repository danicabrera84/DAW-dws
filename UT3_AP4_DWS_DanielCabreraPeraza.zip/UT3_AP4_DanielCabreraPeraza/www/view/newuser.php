<?php
include '../class/class.php';

    if (isset($_COOKIE["ckdatauser"])) { //Si la cookie existe
        setcookie("ckdatauser", time() - 120); //La eliminamos
    }

//----------------------------Conexión a la Base de Datos-------------------------------
    $conexion  = new clsConnection("mysql:host=localhost;dbname=commercedb", "root", "");
    $conexion->Open();
    if ($conexion->IsError()) {
        echo "Se ha producido el error ".$conexion->msgError();
    }
    else{
        $stCity = $conexion->db->prepare('SELECT * FROM city');
        $stCountry = $conexion->db->prepare('SELECT * FROM country');
        $stProvince = $conexion->db->prepare('SELECT * FROM province');
        $stCity->execute(); $stCountry->execute(); $stProvince->execute();
        $resCity = $stCity->fetchAll(); $resCountry = $stCountry->fetchAll(); $resProvince = $stProvince->fetchAll();
    } 
//--------------------------------------------------------------------------------------

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/newuser.css">
    <title>Home</title>
</head>
<body>
<div class="contenedor">
    <h2>Formulario de Registro</h2>
    <form method="post" action="register.php">
        <p><label for="usuario">Usuario: <input type="text" name="usuario" required></label></p>

        <p><label for="contraseña">Contraseña: <input type="text" name="contraseña" required></label></p>
    
        <p><label for="nombre">Nombre: <input type="text" name="nombre" required></label></p>
    
        <p><label for="apellidoA">Primer Apellido: <input type="text" name="apellido1" required></label></p>

        <p><label for="apellidoB">Segundo Apellido: <input type="text" name="apellido2" required></label></p>
    
        <p><label for="fecha">Fecha de Nacimiento: <input type="date" name="fnac" required></label></p>

        <p><label for="calle">Calle: <input type="text" name="calle" required></label></p>

        <p><label for="numero">Numero: <input type="text" name="numero" required></label></p>

        <p><label for="codpostal">Código Postal: <input type="text" name="codpostal" required></label></p>

        <p>
            <label for="municipio">Municipio: 
            <select name="municipio" id="municipio">
            <?php 
                foreach ($resCity as $resultados) {
                    echo '<option value="'.$resultados["cityname"].'">'.$resultados["cityname"].'</option>';
                }
            ?>
            </select>
            </label>
        </p>

        <p>
            <label for="provincia">Provincia: 
            <select name="provincia" id="provincia">
            <?php 
                foreach ($resProvince as $resultados) {
                    echo '<option value="'.$resultados["provincename"].'">'.$resultados["provincename"].'</option>';
                }
            ?>
            </select>      
            </label>
        </p>

        <p>
            <label for="pais">Pais:
            <select name="pais" id="pais">
            <?php 
                foreach ($resCountry as $resultados) {
                    echo '<option value="'.$resultados["countryname"].'">'.$resultados["countryname"].'</option>';
                }
            ?>
            </select>
            </label>
        </p>

        <p><label for="telefono1">Telefono 1: <input type="text" name="telefono1" required></label></p>

        <p><label for="telefono2">Telefono 2: <input type="text" name="telefono2" required></label></p>

        <p><label for="correo">Correo: <input type="text" name="correo" required></label></p>
    
        <p>
            <input type="submit" value="Enviar">
            &nbsp;
            <input type="button" value="Salir" onClick=" window.location.href='../index.php' ">   
        </p>
    </form>
</div>  
</body>
</html>

