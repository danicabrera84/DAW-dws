<?php

include '../library/functions.php';
session_start();

$nombre = $_SESSION['nombre']; $apellido1 = $_SESSION['apellido1'];
$apellido2 = $_SESSION['apellido2']; $direccion = $_SESSION['direccion'];
$numero = $_SESSION['numero']; $codpostal = $_SESSION['codpostal'];
$correo = $_SESSION['correo']; $telefono1 = $_SESSION['telefono1'];
$customerId = $_SESSION['customerid']; $telefono2 = $_SESSION['telefono2'];

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/home.css">
    <title>Home</title>
</head>
<body>
<div class="contenedor">
    <h2>Bienvenido <?php echo $nombre . ' ' . $apellido1 ?></h2>
    
    <p><label for="nombre">Nombre: <?php echo $nombre ?></label></p>
    
    <p><label for="apellido">Apellidos: <?php echo $apellido1 . ' ' . $apellido2 ?></label></p>
    
    <p><label for="direccion">Dirección: <?php echo 'Calle ' . $direccion . ' nº' . $numero ?></label></p>
    
    <p><label for="postal">Codigo Postal: <?php echo $codpostal ?></label></p>
    
    <p><label for="correo">Correo: <?php echo $correo ?></label></p>

    <p><label for="telefono">Teléfono 1: <?php echo $telefono1 ?></label></p>

    <p><label for="telefono">Teléfono 2: <?php echo $telefono2 ?></label></p>

    <form method="get" action="endsesion.php">
    <p><button type="submit">Cerrar Sesión</button></p>
    </form>
</div>   
</body>
</html>