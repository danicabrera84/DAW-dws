<?php
include '../library/functions.php';
include '../class/class.php';
session_start();
getSession();

  
    $conexion  = new clsConnection("mysql:host=localhost;dbname=commercedb", "root", "");
    $conexion->Open();
    if ($conexion->IsError()) {
        echo "Se ha producido el error ".$conexion->msgError();
    }else {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $user = filter_var(($_POST['usuario']), FILTER_SANITIZE_STRING) ;   
            $contraseña = $_POST['contraseña'];$nombre = $_POST['nombre'];
            $fstSurname = $_POST['apellido1'];$scnSurname = $_POST['apellido2'];
            $fecha = $_POST['fnac'];$calle = $_POST['calle'];$numero = $_POST['numero'];       
            $codPostal = $_POST['codpostal'];$fstTel = $_POST['telefono1'];        
            $scnTel = $_POST['telefono2'];$correo = $_POST['correo'];        
            $ciudad = $_POST['municipio'];$provincia = $_POST['provincia'];        
            $pais = $_POST['pais'];        
                    
            $usuario = new clsCliente($user, $contraseña, $nombre, $fstSurname, $scnSurname, $fecha, $calle, $numero, $codPostal, $ciudad, $provincia, $pais, $fstTel, $scnTel, $correo);
            
        $stCity = $conexion->db->prepare('SELECT cityid FROM city WHERE cityname = :cityname'); 
        $stCity->execute(array(':cityname' => $usuario->city));
        $reCity = $stCity->fetch(PDO::FETCH_OBJ);
        $ciudad = $reCity -> cityid;
        
        $stCountry = $conexion->db->prepare('SELECT countryid FROM country WHERE countryname = :countryname');
        $stCountry->execute(array(':countryname' => $usuario->country));
        $reCountry = $stCountry->fetch(PDO::FETCH_OBJ); 
        $pais = $reCountry -> countryid;
        
        $stProvince = $conexion->db->prepare('SELECT provinceid FROM province WHERE provincename = :provincename'); 
        $stProvince->execute(array(':provincename' => $usuario->province));
        $reProvince = $stProvince->fetch(PDO::FETCH_OBJ);
        $provincia = $reProvince -> provinceid;
        
        $stUser = $conexion->db->prepare('SELECT username FROM customer WHERE username = :username'); 
        $stUser->execute(array(':username' => $usuario->user));
        $reUser = $stUser->fetch(PDO::FETCH_OBJ);
        
        $stMail = $conexion->db->prepare('SELECT email FROM customer WHERE email = :email'); 
        $stMail->execute(array(':email' => $usuario->mail));
        $reMail = $stMail->fetch(PDO::FETCH_OBJ);
        
        $fecha = date('Y-m-d H:i:s');
        
        if (empty($reUser) || empty($reMail)) {
            $sql = "INSERT INTO customer(customerid, username, name, firstlastname, secondlastname, birthdaydate, streetdirection, streetnumber, provincecode, 
            cityid, provinceid, countryid, telephone1, telephone2, insertdate, updatedate, password, email)VALUES ('NULL','$usuario->user','$usuario->name','$usuario->fstSurname',
            '$usuario->scnSurname','$usuario->dateBrt','$usuario->street','$usuario->streetNumb','$usuario->zipCode','$ciudad','$provincia','$pais',
            '$usuario->fstPhone','$usuario->scnPhone','$fecha','$fecha','$usuario->pass','$usuario->mail')";
            $stInsert = $conexion->db->prepare($sql);
            $stInsert->execute();
            $result = $stInsert->fetch(PDO::FETCH_OBJ);
        }
        
            $statement = $conexion->db->prepare('SELECT * FROM customer WHERE username = :usuario AND password = :password');
            $statement->execute(array(':usuario' => $usuario->user, ':password' => $usuario->pass ));
            $resultado = $statement->fetch(PDO::FETCH_OBJ);
        
        if ($resultado !== false) {
            if ($conexion->IsValidatedUser()) {
                $_SESSION['usuario'] = $usuario->user;
                $_SESSION['nombre'] = $resultado -> name;
                $_SESSION['apellido1'] = $resultado -> firstlastname;
                $_SESSION['apellido2'] = $resultado -> secondlastname;
                $_SESSION['direccion'] = $resultado -> streetdirection;
                $_SESSION['numero'] = $resultado -> streetnumber;
                $_SESSION['codpostal'] = $resultado -> provincecode;
                $_SESSION['correo'] = $resultado -> email;
                $_SESSION['telefono1'] = $resultado -> telephone1;
                $_SESSION['telefono2'] = $resultado -> telephone2;
                $_SESSION['customerid'] = $resultado -> customerid;
                $customerId = $_SESSION['customerid'];
                setcookie("ckdatauser",$customerId, time() + 120);
                header('Location: home.php');
            }
            
        }else {
            if ($resultado !== true) {// Si la validación es incorrecta
                $usuario->IsError();
                setcookie("ckdatauser","$customerId", time() - 120);// Eliminamos la cookie
                $errorCode14 = "errorCode14";//Generamos un errorCode
                header("Location: newuser.php?".$errorCode14);//Redireccionamos a newuser.php lanzando el erroCode
            }
        }
        
       }  
        
    }
?>