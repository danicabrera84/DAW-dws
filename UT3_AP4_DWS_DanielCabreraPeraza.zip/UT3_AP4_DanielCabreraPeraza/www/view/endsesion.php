<?php
session_start();
$customerId = $_SESSION['customerid']; //Almacenamos en la variable $customerId el valor traido por sesion de customerid
setcookie("ckdatauser","$customerId", time() - 120); //Eliminamos la cookie, nos fijamos que tiene el simbolo menos -

session_destroy(); //Destruimos la sesión
$_SESSION[] = array();//Vaciamos todas la variables de sesion

header('Location: ../index.php'); //Redireccionamos al index al cerrar la sesión
?>
