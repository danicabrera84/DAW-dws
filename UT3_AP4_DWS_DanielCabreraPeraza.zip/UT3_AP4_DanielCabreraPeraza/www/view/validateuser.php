<?php
include '../library/functions.php';
include '../class/class.php';
session_start(); 
                                                                                      
    $conexion  = new clsConnection("mysql:host=localhost;dbname=commercedb", "root", "");
    $conexion->Open();
    if ($conexion->IsError()) {
        echo "Se ha producido el error ".$conexion->msgError();
    }
    else{
            if (isset($_COOKIE["ckdatauser"])) {//Si existe la cookie ckdatauser tomará de ella los datos del customerid
                $stcookie = $conexion->db->prepare('SELECT username, password FROM customer WHERE customerid = :customerid'); //Realizamos la consulta obteniendo usuario y password a traves del curtomerid
                $stcookie->execute(array(':customerid' => $customerid));
                $result = $stcookie->fetch(PDO::FETCH_OBJ);
                $user = $result->username;
                $pass = $result->password; 
                $usuario = new clsUsuario($user, $pass);
        
                $statement = $conexion->db->prepare('SELECT * FROM customer WHERE username = :usuario AND password = :password');
                $statement->execute(array(':usuario' => $usuario->user, ':password' => $usuario->pass ));
                $resultado = $statement->fetch(PDO::FETCH_OBJ);
        
                if ($resultado !== false) {//Si la validación es correcta
                    if ($conexion->IsValidatedUser()) {
                        $_SESSION['usuario'] = $usuario->user;// Si lo es creamos la variable de sesión
                        header('Location: home.php');// Redireccionamos a home.php
                    }  
                }
                else {
                    if ($resultado !== true) {// Si la validación es incorrecta
                        $usuario->IsError();
                        $errorCode1 = "errorCode1";//Generamos un errorCode
                        header("Location: ../index.php?".$errorCode1);//Redireccionamos a index lanzando el erroCode
                    }
                }
        
            }
            else {
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    $user = filter_var(($_POST['usuario']), FILTER_SANITIZE_STRING) ; 
                    $pass = $_POST['contra'];
                    $usuario = new clsUsuario($user, $pass); 
                    $statement = $conexion->db->prepare('SELECT * FROM customer WHERE username = :usuario AND password = :password');
                    $statement->execute(array(':usuario' => $usuario->user, ':password' => $usuario->pass ));
                    $resultado = $statement->fetch(PDO::FETCH_OBJ);
        
                    if ($resultado !== false) {//Si la validación es correcta 
                        if ($conexion->IsValidatedUser()) {
                            $_SESSION['usuario'] = $usuario->user;$_SESSION['nombre'] = $resultado -> name;
                            $_SESSION['apellido1'] = $resultado -> firstlastname;$_SESSION['apellido2'] = $resultado -> secondlastname;
                            $_SESSION['direccion'] = $resultado -> streetdirection;$_SESSION['numero'] = $resultado -> streetnumber;
                            $_SESSION['codpostal'] = $resultado -> provincecode;$_SESSION['correo'] = $resultado -> email;
                            $_SESSION['telefono1'] = $resultado -> telephone1;$_SESSION['telefono2'] = $resultado -> telephone2;
                            $_SESSION['customerid'] = $resultado -> customerid;
                            $customerId = $_SESSION['customerid'];  //Almacenamos el customerid en una variable
                            setcookie("ckdatauser","$customerId", time() + 120);// Creamos la cookie por 2 min
                            header('Location: home.php');// Redireccionamos a home.php
                        }
                        
                    }
                    else {
                        if ($resultado !== true) {// Si la validación es incorrecta
                            $usuario->IsError();
                            setcookie("ckdatauser","$customerId", time() - 120);// Eliminamos la cookie
                            $errorCode1 = "errorCode1";//Generamos un errorCode
                            header("Location: ../index.php?".$errorCode1);//Redireccionamos a index lanzando el erroCode
                        }
                    }
        
                }
            } 
        }
    
    

   
    
     

            
?>