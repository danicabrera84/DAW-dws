<?php
function getSession(){
    if (isset($_SESSION['usuario'])) {
        header('Location: home.php');
    }
}

?>