<?php

class clsUsuario{
    public $user;
    public $pass;

    function __construct($user, $pass){
        $this->user = $user;
        $this->pass = $pass;
    } 
    
    public function IsError(){
        if (isset($_GET['errorCode1'])) {
            $msg = "Usuario o contraseña incorrectos";
            echo "<script type='text/javascript'>alert('$msg');</script>";
        }
        if (isset($_GET['errorCode14'])) {
            $msg = "Ya existe un usuario con los mismos datos";
            echo "<script type='text/javascript'>alert('$msg');</script>";
        }
        if (isset($_GET['errorCode15'])) {
            $msg = "Falta algún campo por rellenar";
            echo "<script type='text/javascript'>alert('$msg');</script>";
        }
        if (isset($_GET['errorCode16'])) {
            $msg = "Error de conexión con la base de datos";
            echo "<script type='text/javascript'>alert('$msg');</script>";
        }
        
    }
}

class clsCliente extends clsUsuario{
    function __construct($user, $pass, $name, $fstSurname, $scnSurname, $dateBrt, $street, $streetNumb, $zipCode, $city, $province,
    $country, $fstPhone, $scnPhone, $mail){
        $this->user = $user;
        $this->pass = $pass;
        $this->name = $name;
        $this->fstSurname = $fstSurname;
        $this->scnSurname = $scnSurname;
        $this->dateBrt = $dateBrt;
        $this->street = $street;
        $this->streetNumb = $streetNumb;
        $this->zipCode = $zipCode;
        $this->city = $city;
        $this->province = $province;
        $this->country = $country;
        $this->fstPhone = $fstPhone;
        $this->scnPhone = $scnPhone;
        $this->mail = $mail;
    }

    
}

class clsConnection{
    public string $host;
    public string $user;
    public string $password;
    public PDO $db;
    public bool $error;
    public string $msgerror;
    public bool $validated;

    public function __construct(string $InHost, string $InUser, string $InPassword) {
        $this->host = $InHost; 
        $this->user = $InUser;
        $this->password = $InPassword;
        $this->error = false;
        $this->msgerror = "";
        $this->validated = true;
    }

    public function Open(){
        try{ 
          $this->db = new PDO($this->host, $this->user, $this->password);
          //$this->db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
          //$this->db->exec("set names utf8mb4");
        } 
        catch (PDOException $e) {
          $this->error = true;
          $this->msgerror = $e->getMessage();  
        }
          
    }

    public function IsValidatedUser(){
        return $this->validated;
    }

    public function IsError(){ 
        return $this->error;   
    }

    public function msgError(){
        return $this->msgError;
    }
}

?>


